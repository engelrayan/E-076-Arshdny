<?php $__env->startSection('title'); ?>
Ershedny
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if(Sentinel::check() ): ?>
<main>
    <div class="big-wrap col-xs-12">
        <div class="user-inner">
            <div class="card preview-card">
                <div class="setting-form col-xs-12">
                    <div class="set-header col-xs-12">
                        <h3>
                            <i class="fa fa-address-card"></i>
                             Hajj Data
                        </h3>
                    </div>
<?php $__currentLoopData = $userInfo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $userInfo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="pre-form col-xs-12" >
                            <div class="pre-inner">
                                <div class="pre-img">
                                    <div class="form-group col-md-12 col-xs-12">
                                        <label>Hajj picture</label>
                                        <div class="profile-img">
                                            <img src="<?php echo e(asset('public/images/'.$userInfo->avatar)); ?>" alt="">
                                        </div>
                                    </div>
                                </div>
                                <div class="pre-data">
                                    <div class="form-group col-md-12 col-xs-12">
                                        <label>Hajj name</label>
                                        <input type="text" class="form-control" disabled value="<?php echo e(Sentinel::getUser()->first_name); ?> <?php echo e(Sentinel::getUser()->last_name); ?>">
                                    </div>
                                    <div class="form-group col-md-12 col-xs-12">
                                        <label> Hajj number</label>
                                        <input type="text" class="form-control"  value="<?php echo e($userInfo->hajNumber); ?>" disabled>
                                    </div>
                                    <div class="form-group col-md-12 col-xs-12">
                                        <label> Border number</label>
                                        <input type="text" class="form-control" value="<?php echo e($userInfo->boardNumber); ?>" disabled>
                                    </div>

                                    <div class="form-group col-md-12 col-xs-12">
                                        <label> His  Adress</label>
                                        <input type="text" class="form-control" value="<?php echo e($userInfo->address); ?>" disabled>
                                    </div>
                                    <div class="form-group col-md-12 col-xs-12">
                                        <label> Group address in Makka </label>
                                        <input type="text" class="form-control" value="<?php echo e($userInfo->hajAddress); ?>" disabled>
                                    </div>
                                    <div class="form-group col-md-12 col-xs-12">
                                        <label> Group Name </label>
                                        <input type="text" class="form-control" value="<?php echo e($userInfo->hamlaName); ?>" disabled>
                                    </div>
                                    <div class="form-group col-md-12 col-xs-12">
                                        <label> Group Number </label>
                                        <input type="text" class="form-control" value="<?php echo e($userInfo->hamlaNumber); ?>" disabled>
                                    </div>
                                    <div class="form-group col-md-12 col-xs-12">
                                        <label> Group PHone Contact </label>
                                        <input type="text" class="form-control" value="<?php echo e($userInfo->hamlaContact); ?>" disabled>
                                    </div>

                                    <div class="form-group col-md-12 col-xs-12">
                                        <label> Hajj  Hralty </label>
                                        <input type="text" class="form-control" value="<?php echo e($userInfo->healty); ?>" disabled>
                                    </div>
                                </div>
                            </div>

                        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</main>
<?php endif; ?>
<?php if(! Sentinel::check() ): ?>

<br><br><br><br>
<a href="<?php echo e(url('qrLogin')); ?>"> <button class="btn btn-lg btn-primary btn-block"  name="Submit" value="QR Read" type="Submit">Qr Read</button><br></a>
<a href="<?php echo e(url('register')); ?>"> <button class="btn btn-lg btn-primary btn-block"  name="Submit" value="Register" type="Submit">Register</button></a>

<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontLayout.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>